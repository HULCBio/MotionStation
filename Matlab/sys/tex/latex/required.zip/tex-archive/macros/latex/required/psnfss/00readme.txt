------------------------------------------------------------
          PSNFSS 9.0c -- installation instructions
------------------------------------------------------------
                                                  2003-03-02
                                              Walter Schmidt
                               

Contents
--------

- Overview
- Removing obsolete files
- Installing the virtual fonts, metrics and .fd files
- Installing the PSNFSS macro packages
- Installing the documentation
- Fonts required for PSNFSS
- Font map files
- The encoding vector 8r.enc
- Extra packages required for PSNFSS
- Making sure that everything works
- Files from PSNFSS v7.x, which are no longer part of the
  distribution.



Overview
--------

PSNFSS, originally developed by Sebastian Rahtz, is a set of
LaTeX2e package files to load common PostScript text and
symbol fonts, together with packages for typesetting math
using virtual math fonts to match Times and Palatino.

The macro packages are useless without the font description
(fd) files, virtual fonts (vf) and font metric (tfm) files
for the font families used.  On CTAN, those for the Base 35
fonts are collected in the file lw35nfss.zip.  Additionally,
metrics, fd's and font map files for the free typefaces
Utopia, Charter and Pazo are provided in the file
freenfss.zip.  

|
| The PSNFSS collection does, however, NOT include the
| actual PostScript fonts, i.e., the .pfb and .afm files. 
| See the below section  "Fonts required for PSNFSS" .
|

This document describes how to _install_ or _update_ PSNFSS.
Detailed instructions how to _use_ PSNFSS with LaTeX can be
found in the PDF document psnfss2e.pdf.



Removing obsolete files
-----------------------

1) If your current version of PSNFSS is 7.0 or older, you
should remove manually _all_ macro files, .fd files, font
metrics and virtual fonts, that have to do with the PSNFSS
system or with the Base35, Utopia or Charter fonts.  

2) If you have installed version 1.x of the mathpazo package
independently of the PSNFSS system, the package file and the
.fd files for the Pazo fonts are to be removed now.

3) If your current version of PSNFSS is 8.x or 9.x, no
further files need to be removed.  Only the existing files
are to be updated.



Installing the virtual fonts, metrics and .fd files
---------------------------------------------------
Skip this section, if you current version of PSNFSS is
already 9.0a as of August 2002.

Obtain the archive files lw35nfss.zip and freenfss.zip from
CTAN:macros/latex/required/psnfss.

If the file system layout of your TeX system complies with
TDS, unzip them in the texmf root directory (usually named
texmf) of your TeX system; all files will be unpacked into
the right directories then.  Otherwise, you have to sort out
manually the files from the .zip archives and copy them to
the appropriate directories of your TeX system.

Note that the archives do _not_ include the metrics of the
"raw" (= not re-encoded) PostScript text fonts.  Whether or
not these metrics are actually required, depends on your TeX
system; besides, they are not special for PSNFSS.



Installing the PSNFSS macro packages
------------------------------------

Copy the files 

  00readme.txt
  changes.txt
  manifest.txt
  mathtest.tex
  pitest.tex
  psfonts.dtx
  psfonts.ins
  psnfss2e.tex
  test0.tex
  test1.tex
  test2.tex
  test3.tex

to a directory where you keep documented LaTeX sources.
In a TDS compliant system this should be the directory

  texmf/source/latex/psnfss.

Run LaTeX on the installation script psfonts.ins to create
the package (.sty) files.  Move them to a directory where
LaTeX will find them.  In a TDS compliant system this should
be the directory

  texmf/tex/latex/psnfss.

The latter step is executed automagically by the
installation script, provided that your DocStrip program has
been configured appropriately and the target directory
exists already.



Installing the documentation
----------------------------

Copy the documentation file psnfss2e.pdf to a suitable
directory; in a TDS compliant system this should be

  texmf/doc/latex/psnfss.



Fonts required for PSNFSS
-------------------------

The "Base 35" fonts
  Whether or not these fonts must be available to the dvi
  driver as "real" Type1 fonts, depends on the particular
  application (dvips, pdfTeX, VTeX etc.)  and whether the 
  fonts are to be embedded into the final PostScript or PDF
  documents.
  
Adobe Utopia
Bitstream Charter
  The Type1 font files can be obtained for free from
  various sources, e.g., CTAN:fonts/utopia and
  CTAN:fonts/charter.  
  
Pazo
  The Type1 fonts can be obtained from the CTAN directory
  fonts/mathpazo.  Notice that PSNFSS 9 needs a recent
  version 1.003 (2002-05-17) of the Pazo fonts
  
Computer Modern
RSFS (Ralph Smith's Formal Script)
Euler Math
  These font families are required when typesetting math
  using the packages mathptm, mathptmx, mathpple, or
  mathpazo.
  
  They are available in Type1 as well as METAFONT format; it
  is recommended to provide the Type1 variants, if you want
  to create PostScript or PDF documents.  The particular
  fonts eurm10 (Euler Roman 10pt) and eurb10 (Euler Roman
  Bold 10pt) are special:  They _must_ be provided in Type1
  format so that obliqued versions, named eurmo10 and
  eurbo10, can be generated from them.



Font map files
--------------

The following font map files are provided in the PSNFSS
distribution:

  psnfss.map:     for the Base35 fonts, eurmo10 and eurbo10
  charter.map:    for Bitstream Charter
  utopia.map:     for Adobe Utopia
  pazo.map        for the Pazo math fonts

psnfss.map is primarily destined for use with dvips.  The
entries for the fonts "eurmo10" and "eurbo10" may need to be
customized:  Feel free to change the FontNames (EURM10,
EURB10) to lower case, if you have got the Type1 fonts from
MicroPress rather than the BlueSky collection.  This
particular change is _not_ regarded as a violation of the
license conditions.

psnfss.map does _not_ make dvips embed the Base35 fonts.
For use with pdfTeX you will have to create a modified copy,
that embeds all fonts This new map file may also be useful
for dvips, if you want to make it embed all fonts.

The map files charter.map, utopia.map and pazo.map are
equally suitable for use with either dvips or pdfTeX.

Consult the documentation of your TeX system, how to install
font map files for dvips and pdfTeX!

Other applications, such as VTeX, need a different format of
the font map files.  They may also require entries for the
raw (= not reencoded) fonts.  When creating these map files,
you may take those for dvips as a model.



The encoding vector 8r.enc
--------------------------

Most Type1 text fonts, when used from TeX, are reencoded to
the so-called TeXBase1 encoding, in order to make all glyphs
accessible.  This is performed using the reencoding file

  8r.enc
  
which distributed with PSNFSS.  Consult the documentation of
your TeX system, where to store this file!

|
| PSNFSS 9.0c includes version 2.0 of 8r.enc.  Make sure
| that there exist no other, obsolete, instances of 8r.enc
| in the relevant search path of your TeX system
|



Extra packages required for PSNFSS
----------------------------------

The "Graphics" bundle must be installed, since PSNFSS makes
use of the package keyval.sty.



Making sure that everything works
---------------------------------

Run the test following files through LaTeX:

  test0.tex
  test1.tex
  test2.tex
  test3.tex
  mathtest.tex 
  pitest.tex



Files from PSNFSS v7.x, which are no longer part of the
distribution
-------------------------------------------------------

The files to support the commercial Lucida Bright and
MathTime fonts are now distributed from the CTAN directories
macros/latex/contrib/supported/psnfssx/ and
fonts/metrics/bh/lucida/.


-- finis
