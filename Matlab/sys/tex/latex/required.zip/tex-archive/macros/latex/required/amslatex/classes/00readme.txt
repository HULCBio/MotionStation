00readme.txt for AMS document classes amsart/book/proc 2.0 [2000/06/06]

See manifest.txt for a list of all the files in the distribution.

See install.txt for installation instructions.

The document classes amsart, amsbook, amsproc and related packages are
provided by the American Mathematical Society for authors to use with
LaTeX. They produce the overall layout and appearance of AMS
publications.

In order to use an AMS document class you need to have TeX software
installed first. TeX is not an AMS product. If you need information on
getting TeX see one of the following:

  http://www.tug.org/
  http://www.ams.org/tex/tex-resources.html

Documentation for the AMS document classes is found in

  instr-l.dvi
  diffs-c.txt
  amsclass.faq
  amsthdoc.dvi
  thmtest.tex

The recommended procedure for making a custom document class based on an
AMS class is to make a copy of the relevant .cls file using a different
name and edit the copy---e.g., copy amsbook.cls to mybook.cls. (In
general we advise against using \LoadClass, unless the base class is
frozen or changes to the base class are under your control.)

For technical support:

  American Mathematical Society
  Technical Support
  Electronic Products and Services
  P. O. Box 6248
  Providence, RI 02940-6248
  Phone: 800-321-4AMS (321-4267) (USA/Canada) or 401-455-4080
  tech-support@ams.org

========================================================================
RECENT BUG FIXES

---amsthdoc.tex 2.02 2000/06/06
Use article class instead of amsldoc (which is overkill).

---amsldoc.cls - 2000/06/06
Removed from distribution, no longer needed by amsthdoc.

---amsclass.dtx 2.07 2000/06/05
Guard against \\ in argument of \author.

---amsclass.dtx 2.06 2000/06/02
Avoid using \@elt in qed stack because LaTeX output routine falls over
if triggered when something else is using \@elt.

---amsclass.dtx 2.05 2000/05/16
1. Added \indexintro.
2. Fixed erroneous init for thm@preskip, thm@postskip.

---amsclass.dtx 2.04 2000/03/10
\newtoks fix for old versions of LaTeX. Added some commentary about \cal.

---amsclass.dtx 2.03 2000/01/17
1. Removed dependency on amsgen package.
2. Added a warning about graphics for the draft option.
3. Improved qedhere handling for article/amsthm combination.

---amsclass.dtx 2.02 2000/01/17
Some fixes for the fleqn/qedhere case.
