#ifndef K32CALL_H
#define K32CALL_H

extern "C"
{
  DWORD WINAPI GetK32ProcAddress(int ord);
}

#endif
