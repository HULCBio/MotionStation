#ifndef GENERAL_H
#define GENERAL_H

extern bool IsNT;
extern HANDLE hDriver;
extern bool IsWinIoInitialized;

#endif
